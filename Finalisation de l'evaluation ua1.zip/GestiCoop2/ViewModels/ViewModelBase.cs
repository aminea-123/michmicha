﻿
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace GestiCoop2.ViewModels
{
    public class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged(
            [CallerMemberName] string? nom = null)
        {
            PropertyChanged?.Invoke(
                this, new PropertyChangedEventArgs(nom));
        }
    }
}

