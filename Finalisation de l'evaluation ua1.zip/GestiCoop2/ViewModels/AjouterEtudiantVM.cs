﻿
using System;
using System.Text.RegularExpressions;
using System.Windows.Input;

namespace GestiCoop2.ViewModels
{
    public class AjouterEtudiantVM : ViewModelBase
    {
        private string nom = "";
        private string prenom = "";
        private string courriel = "";
        private string programme = "";
        private string numeroEtudiant = "";

        public string Nom
        {
            get => nom;
            set
            {
                nom = value;
                OnPropertyChanged();
                ActualiserValidation();
            }
        }

        public string Prenom
        {
            get => prenom;
            set
            {
                prenom = value;
                OnPropertyChanged();
                ActualiserValidation();
            }
        }

        public string Courriel
        {
            get => courriel;
            set
            {
                courriel = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CourrielInvalide));
                OnPropertyChanged(nameof(MessageCourriel));
                ActualiserValidation();
            }
        }

        public string Programme
        {
            get => programme;
            set
            {
                programme = value;
                OnPropertyChanged();
                ActualiserValidation();
            }
        }

        public string NumeroEtudiant
        {
            get => numeroEtudiant;
            set
            {
                numeroEtudiant = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(NumeroInvalide));
                ActualiserValidation();
            }
        }

        public bool CourrielInvalide =>
            !string.IsNullOrWhiteSpace(Courriel) &&
            !Regex.IsMatch(
                Courriel,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$");

        public string MessageCourriel =>
            CourrielInvalide
                ? "Adresse courriel invalide — ex. : prenom.nom@etud.lacite.ca"
                : "";

        public bool NumeroInvalide =>
            !string.IsNullOrWhiteSpace(NumeroEtudiant) &&
            !Regex.IsMatch(NumeroEtudiant, @"^\d{7}$");

        public bool FormulaireValide =>
            !string.IsNullOrWhiteSpace(Nom) &&
            !string.IsNullOrWhiteSpace(Prenom) &&
            !string.IsNullOrWhiteSpace(Courriel) &&
            !string.IsNullOrWhiteSpace(Programme) &&
            Regex.IsMatch(
                Courriel,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$") &&
            !NumeroInvalide;

        public ICommand EnregistrerCommand { get; }

        public event Action? EnregistrementReussi;

        public AjouterEtudiantVM()
        {
            EnregistrerCommand = new RelayCommand(
                _ => Enregistrer(),
                _ => FormulaireValide);
        }

        private void ActualiserValidation()
        {
            OnPropertyChanged(nameof(FormulaireValide));
            CommandManager.InvalidateRequerySuggested();
        }

        private void Enregistrer()
        {
            if (FormulaireValide)
            {
                EnregistrementReussi?.Invoke();
            }
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object?> execute;
        private readonly Predicate<object?> canExecute;

        public RelayCommand(
            Action<object?> execute,
            Predicate<object?> canExecute)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        public bool CanExecute(object? parameter)
        {
            return canExecute(parameter);
        }

        public void Execute(object? parameter)
        {
            execute(parameter);
        }

        public event EventHandler? CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }
    }
}

