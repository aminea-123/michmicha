﻿
using System.Windows;
using GestiCoop2.ViewModels;

namespace GestiCoop2.Views
{
    public partial class AjouterEtudiantWindow : Window
    {
        public AjouterEtudiantVM ViewModel { get; }

        public AjouterEtudiantWindow()
        {
            InitializeComponent();

            // Création du ViewModel
            ViewModel = new AjouterEtudiantVM();

            // Liaison du formulaire au ViewModel
            DataContext = ViewModel;

            // fermeture après enregistrement réussi
            ViewModel.EnregistrementReussi += () =>
            {
                DialogResult = true;
            };
        }

        // bouton annuler
        private void Annuler_Click(
            object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}


