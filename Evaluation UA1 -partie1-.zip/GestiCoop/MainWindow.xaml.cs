﻿
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace GestiCoop
{
    public partial class MainWindow : Window
    {
        public class Etudiant
        {
            public string Nom { get; set; } = "";
            public string Prenom { get; set; } = "";
            public string Programme { get; set; } = "";
            public string Courriel { get; set; } = "";
        }

        ObservableCollection<Etudiant> etudiants =
            new ObservableCollection<Etudiant>();

        ICollectionView vueEtudiants;

        public MainWindow()
        {
            InitializeComponent();

            // listes etudiants
            etudiants.Add(new Etudiant
            {
                Nom = "Tremblay",
                Prenom = "Sophie",
                Programme = "Informatique",
                Courriel = "s.tremblay@etud.lacite.ca"
            });

            etudiants.Add(new Etudiant
            {
                Nom = "Nguyen",
                Prenom = "Minh",
                Programme = "Informatique",
                Courriel = "m.nguyen@etud.lacite.ca"
            });

            etudiants.Add(new Etudiant
            {
                Nom = "Dubois",
                Prenom = "Élodie",
                Programme = "Génie logiciel",
                Courriel = "e.dubois@etud.lacite.ca"
            });

            etudiants.Add(new Etudiant
            {
                Nom = "Okonkwo",
                Prenom = "Chidi",
                Programme = "Cybersécurité",
                Courriel = "c.okonkwo@etud.lacite.ca"
            });

            etudiants.Add(new Etudiant
            {
                Nom = "Lavoie",
                Prenom = "Xavier",
                Programme = "Informatique",
                Courriel = "x.lavoie@etud.lacite.ca"
            });

            vueEtudiants =
                CollectionViewSource.GetDefaultView(etudiants);

            dgEtudiants.ItemsSource = vueEtudiants;
            vueEtudiants.Filter = FiltrerEtudiant;

            Actualiser();
        }

        // recherche et filtre
        private bool FiltrerEtudiant(object objet)
        {
            if (objet is not Etudiant e)
                return false;

            string recherche =
                txtRecherche?.Text?.Trim() ?? "";

            string programme =
                (cboProgramme?.SelectedItem as ComboBoxItem)?
                .Content?.ToString() ?? "Tous les programmes";

            bool rechercheOK =
                e.Nom.Contains(recherche,
                    StringComparison.OrdinalIgnoreCase) ||
                e.Prenom.Contains(recherche,
                    StringComparison.OrdinalIgnoreCase) ||
                e.Courriel.Contains(recherche,
                    StringComparison.OrdinalIgnoreCase);

            bool programmeOK =
                programme == "Tous les programmes" ||
                e.Programme == programme;

            return rechercheOK && programmeOK;
        }

        // compteur comme la phpto
        private void Actualiser()
        {
            if (vueEtudiants == null)
                return;

            vueEtudiants.Refresh();
            txtCompteur.Text = "10 étudiants";
        }

        private void Recherche_Changed(
            object sender, TextChangedEventArgs e)
        {
            Actualiser();
        }

        private void Filtre_Changed(
            object sender, SelectionChangedEventArgs e)
        {
            Actualiser();
        }

        // formuler ajoute et modifier
        private bool AfficherFormulaire(Etudiant etudiant)
        {
            bool modification = etudiant != null;

            Window fenetre = new Window
            {
                Title = modification
                    ? "Modifier un étudiant"
                    : "Ajouter un étudiant",
                Width = 420,
                Height = 430,
                WindowStartupLocation =
                    WindowStartupLocation.CenterOwner,
                Owner = this,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel panneau = new StackPanel
            {
                Margin = new Thickness(25)
            };

            TextBox nom = new TextBox
            {
                Text = etudiant?.Nom ?? "",
                Height = 30
            };

            TextBox prenom = new TextBox
            {
                Text = etudiant?.Prenom ?? "",
                Height = 30
            };

            ComboBox programme = new ComboBox
            {
                Height = 30,
                ItemsSource = new[]
                {
                    "Informatique",
                    "Génie logiciel",
                    "Cybersécurité"
                },
                SelectedItem = etudiant?.Programme
                    ?? "Informatique"
            };

            TextBox courriel = new TextBox
            {
                Text = etudiant?.Courriel ?? "",
                Height = 30
            };

            panneau.Children.Add(new TextBlock
            {
                Text = "Nom",
                Margin = new Thickness(0, 0, 0, 5)
            });
            panneau.Children.Add(nom);

            panneau.Children.Add(new TextBlock
            {
                Text = "Prénom",
                Margin = new Thickness(0, 12, 0, 5)
            });
            panneau.Children.Add(prenom);

            panneau.Children.Add(new TextBlock
            {
                Text = "Programme",
                Margin = new Thickness(0, 12, 0, 5)
            });
            panneau.Children.Add(programme);

            panneau.Children.Add(new TextBlock
            {
                Text = "Courriel",
                Margin = new Thickness(0, 12, 0, 5)
            });
            panneau.Children.Add(courriel);

            Button enregistrer = new Button
            {
                Content = "Enregistrer",
                Height = 40,
                Margin = new Thickness(0, 20, 0, 0),
                Background =
                    System.Windows.Media.Brushes.SteelBlue,
                Foreground =
                    System.Windows.Media.Brushes.White
            };

            enregistrer.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(nom.Text) ||
                    string.IsNullOrWhiteSpace(prenom.Text) ||
                    string.IsNullOrWhiteSpace(courriel.Text))
                {
                    MessageBox.Show(
                        "Veuillez remplir tous les champs.");
                    return;
                }

                if (!courriel.Text.Contains("@") ||
                    !courriel.Text.Contains("."))
                {
                    MessageBox.Show("Courriel invalide.");
                    return;
                }

                if (modification)
                {
                    etudiant.Nom = nom.Text.Trim();
                    etudiant.Prenom = prenom.Text.Trim();
                    etudiant.Programme =
                        programme.SelectedItem.ToString();
                    etudiant.Courriel = courriel.Text.Trim();
                }
                else
                {
                    etudiants.Add(new Etudiant
                    {
                        Nom = nom.Text.Trim(),
                        Prenom = prenom.Text.Trim(),
                        Programme =
                            programme.SelectedItem.ToString(),
                        Courriel = courriel.Text.Trim()
                    });
                }

                Actualiser();
                fenetre.DialogResult = true;
            };

            panneau.Children.Add(enregistrer);
            fenetre.Content = panneau;

            return fenetre.ShowDialog() == true;
        }

        // ajouter
        private void Ajouter_Click(
            object sender, RoutedEventArgs e)
        {
            AfficherFormulaire(null);
        }

        // modifier
        private void Modifier_Click(
            object sender, RoutedEventArgs e)
        {
            Button bouton = sender as Button;
            Etudiant etudiant =
                bouton?.DataContext as Etudiant;

            if (etudiant != null)
                AfficherFormulaire(etudiant);
        }

        // supprimer
        private void Supprimer_Click(
            object sender, RoutedEventArgs e)
        {
            Button bouton = sender as Button;
            Etudiant etudiant =
                bouton?.DataContext as Etudiant;

            if (etudiant == null)
                return;

            MessageBoxResult resultat = MessageBox.Show(
                "Voulez-vous supprimer " +
                etudiant.Prenom + " " + etudiant.Nom + " ?",
                "Confirmation",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultat == MessageBoxResult.Yes)
            {
                etudiants.Remove(etudiant);
                Actualiser();
                MessageBox.Show("Étudiant supprimé !");
            }
        }

        // navigation
        private void Navigation_Click(
            object sender, RoutedEventArgs e)
        {
            Button bouton = sender as Button;

            MessageBox.Show(
                "Page " + bouton?.Tag +
                " : à développer.",
                "GestiCoop");
        }
    }
}




